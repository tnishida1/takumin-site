---
name: Wooly McBaa
image: /images/wooly.jpg
---
